chrome.downloads.onDeterminingFilename.addListener(function(e,n){var l=e.filename.substring(e.filename.lastIndexOf(".")+1),a=e.filename.substring(0,e.filename.lastIndexOf("."))
a=a.split("_")
var i=a[1].length
6==i?(file_name=a[4]+"_"+a[a.length-1],folder_name=a[1]+"_"+a[2],n({filename:folder_name+"/"+file_name+"."+l})):4==i?(file_name=a[3],folder_name=a[a.length-2]+"_"+a[a.length-1],n({filename:folder_name+"/"+file_name+"."+l})):n({filename:"VIT downloads/"+e.filename})})
