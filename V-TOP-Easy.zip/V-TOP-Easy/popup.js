var _gaq=_gaq||[]
_gaq.push(["_setAccount","UA-75111209-3"]),_gaq.push(["_trackPageview"]),function(){var t=document.createElement("script")
t.type="text/javascript",t.async=!0,t.src="https://ssl.google-analytics.com/ga.js"
var a=document.getElementsByTagName("script")[0]
a.parentNode.insertBefore(t,a)}(),$("a").attr("target","_blank")
